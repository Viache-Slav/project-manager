import { useState } from 'react'
import './App.css'

function App() {
  return (
    <div>
      <h1>Приложение запущено</h1>
    </div>
  )
}

export default App
